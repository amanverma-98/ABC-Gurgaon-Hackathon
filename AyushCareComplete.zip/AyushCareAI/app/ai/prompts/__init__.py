# AI prompt templates
