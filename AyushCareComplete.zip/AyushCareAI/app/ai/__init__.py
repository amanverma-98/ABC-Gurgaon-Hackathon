# AI provider abstraction layer
